#include <iostream>

using namespace std;

int main(){

	cout << "Hello World! G++ Compiler is working too" << endl;

	return 0;

}