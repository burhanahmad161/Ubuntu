**Manual For Installing Ubuntu**

- First of all set the VMware station for running the ubuntu file.

- After creating a virtual disk for ubuntu run that virtual disk.

![](Ubuntu/Capture1.PNG)

This screen will appear when you run the virtual disk.

![](Ubuntu/Capture2.png)

Select your Language and click Next.

![](Ubuntu/Capture3.PNG)

Select Install Ubuntu and then click next.

![](Ubuntu/Capture4.PNG)

Select your keyboard layout and then click next.

![](Ubuntu/Capture5.PNG)

Select weather you want to connect to the internet and then click Next.

![](Ubuntu/Capture6.PNG)

Update if you want or else click Skip.

![](Ubuntu/Capture7.PNG)

Select Default Installation and click Next.

![](Ubuntu/Capture8.PNG)

Select Erase Disk and Install Ubuntu and then click Next.

![](Ubuntu/Capture9.PNG)

Click Install.

![](Ubuntu/Capture10.PNG)

Select your region and click Next

![](Ubuntu/Capture11.PNG)

Enter your details i.e you name,computer’s name, username and password and then Click Next.

![](Ubuntu/Capture12.png)

Select your desired theme and then click Next.

![](Ubuntu/Capture13.png)

Installation will begin and it will take some time.

After some time and the setup will be completed and you can run ubuntu through VMWare Station.

![](Ubuntu/Capture14.png)
