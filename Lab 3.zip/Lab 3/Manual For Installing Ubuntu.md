**Basic Ubuntu Commands**

## **Lab 3**

![](New Folder/1.png)

Touch command is used to create a new file. Nano command is used to write in the file and if we use “\>” after two files it will merge those two files into one file.

![](New folder/2.png)

Head command is used to write starting lines of file and tail command is used to write last lines of file.

![](New folder/3.png)

Grep is used to search for a word in the file.

![](New folder/4.png)

Chmod command is used to edit the permissions of the file.

![](New folder/6.png)

Pwd command is used to view the current repository. Mkdir is used to create a new Folder. Time is used to get current time. Echo is used to display text and touch is used to write text in a file.

![](New folder/7.png)

![](New folder/8.png)

![](New folder/9.png)

GitHub Link: https://github.com/burhanahmad161/Ubuntu
